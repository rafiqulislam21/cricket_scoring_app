<script src="{{asset('admin')}}/vendors/base/vendor.bundle.base.js"></script>

</script>
<!-- endinject -->
<!-- Plugin js for this page-->
<script src="{{asset('admin')}}/vendors/chart.js/Chart.min.js"></script>
<!-- End plugin js for this page-->
<!-- inject:js -->
<script src="{{asset('admin')}}/js/off-canvas.js"></script>
<script src="{{asset('admin')}}/js/hoverable-collapse.js"></script>
<script src="{{asset('admin')}}/js/template.js"></script>
<script src="{{asset('admin')}}/js/todolist.js"></script>
<!-- endinject -->
<!-- Custom js for this page-->
<script src="{{asset('admin')}}/js/dashboard.js"></script>
<!-- End custom js for this page-->
<script src="{{asset('admin')}}/js/todolist.js"></script>

<!-- endinject -->
<!-- Custom js for this page-->
<script src="{{asset('admin')}}/js/chart.js"></script>

<script>
  function myFunction() {
    document.getElementById("addFix").reset();
  }
</script>

<!-- Go to www.addthis.com/dashboard to customize your tools -->
<!-- <script type="text/javascript" src="https://s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5d3bf27556bc3aa6"></script> -->
